if (!customElements.get('product-form')) {
  customElements.define(
    'product-form',
    class ProductForm extends HTMLElement {
      constructor() {
        super();

        this.form = this.querySelector('form');
        this.variantIdInput.disabled = false;
        this.form.addEventListener('submit', this.onSubmitHandler.bind(this));
        this.cart = document.querySelector('cart-notification') || document.querySelector('cart-drawer');
        this.submitButton = this.querySelector('[type="submit"]');
        this.submitButtonText = this.submitButton.querySelector('[data-submit-content]') || this.submitButton.querySelector('span');
        this.submitButtonDefault = this.submitButton.querySelector('[data-submit-default]');
        this.submitButtonState = this.submitButton.querySelector('[data-submit-state]');

        if (document.querySelector('cart-drawer')) this.submitButton.setAttribute('aria-haspopup', 'dialog');

        this.hideErrors = this.dataset.hideErrors === 'true';
      }

      onSubmitHandler(evt) {
        evt.preventDefault();
        if (this.submitButton.disabled || this.submitButton.getAttribute('aria-disabled') === 'true' ||
            this.closest('product-info')?.dataset.bcNavigating === 'true') return;

        const quantity = this.form.elements.namedItem('quantity');
        if (quantity && (!quantity.value.trim() || !quantity.checkValidity())) {
          this.handleErrorMessage('Vul een geldig aantal in.');
          quantity.focus();
          quantity.reportValidity();
          return;
        }

        const inbouwAddon = this.form.querySelector('bc-inbouw-addon');
        if (inbouwAddon) {
          if (typeof inbouwAddon.handleSubmit !== 'function' || !inbouwAddon.ready) {
            this.handleErrorMessage(inbouwAddon.dataset.messageLoading || inbouwAddon.dataset.messageChanged);
            return;
          }
          if (inbouwAddon.handleSubmit(this)) return;
        }

        this.handleErrorMessage();

        this.submitButton.setAttribute('aria-disabled', true);
        this.submitButton.setAttribute('aria-busy', 'true');
        this.submitButton.classList.add('loading');
        this.querySelector('.loading__spinner').classList.remove('hidden');

        const config = fetchConfig('javascript');
        config.headers['X-Requested-With'] = 'XMLHttpRequest';
        delete config.headers['Content-Type'];

        const formData = new FormData(this.form);
        if (this.cart) {
          formData.append(
            'sections',
            this.cart.getSectionsToRender().map((section) => section.id)
          );
          formData.append('sections_url', window.location.pathname);
          this.cart.setActiveElement(document.activeElement);
        }
        config.body = formData;

        fetch(`${routes.cart_add_url}`, config)
          .then((response) => response.json())
          .then((response) => {
            if (response.status) {
              publish(PUB_SUB_EVENTS.cartError, {
                source: 'product-form',
                productVariantId: formData.get('id'),
                errors: response.errors || response.description,
                message: response.message,
              });
              this.handleErrorMessage(response.description);

              const soldOutMessage = this.submitButton.querySelector('.sold-out-message');
              if (!soldOutMessage) return;
              this.submitButton.setAttribute('aria-disabled', true);
              this.submitButtonText.classList.add('hidden');
              soldOutMessage.classList.remove('hidden');
              this.error = true;
              return;
            } else if (!this.cart) {
              window.location = window.routes.cart_url;
              return;
            }

            const startMarker = CartPerformance.createStartingMarker('add:wait-for-subscribers');
            if (!this.error)
              publish(PUB_SUB_EVENTS.cartUpdate, {
                source: 'product-form',
                productVariantId: formData.get('id'),
                cartData: response,
              }).then(() => {
                CartPerformance.measureFromMarker('add:wait-for-subscribers', startMarker);
              });
            this.error = false;
            const quickAddModal = this.closest('quick-add-modal');
            if (quickAddModal) {
              document.body.addEventListener(
                'modalClosed',
                () => {
                  setTimeout(() => {
                    CartPerformance.measure("add:paint-updated-sections", () => {
                      this.cart.renderContents(response);
                    });
                  });
                },
                { once: true }
              );
              quickAddModal.hide(true);
            } else {
              CartPerformance.measure("add:paint-updated-sections", () => {
                this.cart.renderContents(response);
              });
            }
          })
          .catch((e) => {
            console.error(e);
            this.handleErrorMessage('Toevoegen kon niet worden bevestigd. Controleer je winkelwagen en probeer zo nodig opnieuw.');
          })
          .finally(() => {
            this.submitButton.classList.remove('loading');
            this.submitButton.removeAttribute('aria-busy');
            if (this.cart && this.cart.classList.contains('is-empty')) this.cart.classList.remove('is-empty');
            if (!this.error) this.submitButton.removeAttribute('aria-disabled');
            this.querySelector('.loading__spinner').classList.add('hidden');

            CartPerformance.measureFromEvent("add:user-action", evt);
          });
      }

      handleErrorMessage(errorMessage = false) {
        if (this.hideErrors) return;

        this.errorMessageWrapper =
          this.errorMessageWrapper || this.querySelector('.product-form__error-message-wrapper');
        if (!this.errorMessageWrapper) return;
        this.errorMessage = this.errorMessage || this.errorMessageWrapper.querySelector('.product-form__error-message');

        this.errorMessageWrapper.toggleAttribute('hidden', !errorMessage);

        if (errorMessage) {
          this.errorMessage.textContent = errorMessage;
        }
      }

      toggleSubmitButton(disable = true, text) {
        if (disable) {
          this.submitButton.setAttribute('disabled', 'disabled');
          if (text) {
            if (this.submitButtonDefault && this.submitButtonState) {
              this.submitButtonDefault.classList.add('hidden');
              this.submitButtonState.classList.remove('hidden');
              this.submitButtonState.textContent = text;
            } else {
              this.submitButtonText.textContent = text;
            }
          }
        } else {
          this.submitButton.removeAttribute('disabled');
          if (this.submitButtonDefault && this.submitButtonState) {
            this.submitButtonDefault.classList.remove('hidden');
            this.submitButtonState.classList.add('hidden');
            this.submitButtonState.textContent = '';
          } else {
            this.submitButtonText.textContent = window.variantStrings.addToCart;
          }
        }
      }

      get variantIdInput() {
        return this.form.querySelector('[name=id]');
      }
    }
  );
}

